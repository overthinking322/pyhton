person = {
    "name": "John",
    "age": 30,
    "city": "New York"
}
other_person = {
    "city": "New York",
    "age": 30,
    "name": "John",
}
print(person == other_person)  # Outputs: True
