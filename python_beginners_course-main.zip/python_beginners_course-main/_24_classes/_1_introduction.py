my_string = "Hello, World!"
print(type(my_string))  # Output: <class 'str'>


class MyClass:
    pass


print(type(MyClass))  # Output: <class 'type'>
my_class = MyClass()
print(type(my_class))  # Output: <class '__main__.MyClass'>
