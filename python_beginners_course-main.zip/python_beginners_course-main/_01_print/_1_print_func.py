print("Hello, world!")


print("Hello,", "world!")


print("Hello", "world", sep=", ")


print("First row")
print("Second row")


print("First row", end=" ")
print("Second row")
