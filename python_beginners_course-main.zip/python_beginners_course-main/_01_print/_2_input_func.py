input("Please enter something: ")


name = input("Enter your name: ")
print("My name is: ", name)
