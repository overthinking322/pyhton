Python course for beginners. 

Author: Alexander Ilyin. 

Telegram: https://t.me/digital_ninjaa
YouTube: https://www.youtube.com/@digital_ninja